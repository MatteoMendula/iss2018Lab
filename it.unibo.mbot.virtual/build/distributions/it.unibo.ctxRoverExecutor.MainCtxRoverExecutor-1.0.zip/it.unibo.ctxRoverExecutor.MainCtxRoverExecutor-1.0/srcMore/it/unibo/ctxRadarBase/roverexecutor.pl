%====================================================================================
% Context ctxRadarBase standalone= SYSTEM-configuration: file it.unibo.ctxRadarBase.roverExecutor.pl 
%====================================================================================
context(ctxradarbase, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
