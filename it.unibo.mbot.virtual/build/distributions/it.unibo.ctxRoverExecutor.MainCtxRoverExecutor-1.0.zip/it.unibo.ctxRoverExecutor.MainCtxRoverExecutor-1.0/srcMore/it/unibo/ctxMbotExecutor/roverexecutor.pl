%====================================================================================
% Context ctxMbotExecutor standalone= SYSTEM-configuration: file it.unibo.ctxMbotExecutor.roverExecutor.pl 
%====================================================================================
context(ctxmbotexecutor, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
