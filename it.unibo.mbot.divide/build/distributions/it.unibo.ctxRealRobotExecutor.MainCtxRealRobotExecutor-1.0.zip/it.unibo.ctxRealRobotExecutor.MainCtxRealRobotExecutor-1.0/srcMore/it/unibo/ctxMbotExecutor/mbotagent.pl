%====================================================================================
% Context ctxMbotExecutor standalone= SYSTEM-configuration: file it.unibo.ctxMbotExecutor.mbotAgent.pl 
%====================================================================================
context(ctxmbotexecutor, "192.168.43.67",  "TCP", "8029" ).  		 
%%% -------------------------------------------
