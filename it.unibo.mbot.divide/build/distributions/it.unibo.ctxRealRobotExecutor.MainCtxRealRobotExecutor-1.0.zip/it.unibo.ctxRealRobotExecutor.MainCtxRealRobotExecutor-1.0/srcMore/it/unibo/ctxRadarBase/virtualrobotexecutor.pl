%====================================================================================
% Context ctxRadarBase standalone= SYSTEM-configuration: file it.unibo.ctxRadarBase.virtualRobotExecutor.pl 
%====================================================================================
context(ctxradarbase, "192.168.43.229",  "TCP", "8033" ).  		 
%%% -------------------------------------------
