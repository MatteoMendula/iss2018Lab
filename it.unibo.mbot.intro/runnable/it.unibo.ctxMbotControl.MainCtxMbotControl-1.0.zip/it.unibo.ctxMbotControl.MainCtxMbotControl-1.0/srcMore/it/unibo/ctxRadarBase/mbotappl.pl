%====================================================================================
% Context ctxRadarBase standalone= SYSTEM-configuration: file it.unibo.ctxRadarBase.mbotAppl.pl 
%====================================================================================
context(ctxradarbase, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
