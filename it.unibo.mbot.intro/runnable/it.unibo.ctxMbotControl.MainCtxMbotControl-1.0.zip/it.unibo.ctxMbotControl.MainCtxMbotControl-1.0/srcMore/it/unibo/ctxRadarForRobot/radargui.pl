%====================================================================================
% Context ctxRadarForRobot  SYSTEM-configuration: file it.unibo.ctxRadarForRobot.radargui.pl 
%====================================================================================
context(ctxradarforrobot, "localhost",  "TCP", "8033" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
qactor( radarrobot , ctxradarforrobot, "it.unibo.radarrobot.MsgHandle_Radarrobot"   ). %%store msgs 
qactor( radarrobot_ctrl , ctxradarforrobot, "it.unibo.radarrobot.Radarrobot"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

