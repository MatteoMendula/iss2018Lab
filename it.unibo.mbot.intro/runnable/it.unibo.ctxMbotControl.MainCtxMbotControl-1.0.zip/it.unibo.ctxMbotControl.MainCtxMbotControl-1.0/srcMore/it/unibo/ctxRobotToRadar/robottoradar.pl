%====================================================================================
% Context ctxRobotToRadar  SYSTEM-configuration: file it.unibo.ctxRobotToRadar.robotToRadar.pl 
%====================================================================================
context(ctxrobottoradar, "localhost",  "TCP", "8055" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
qactor( populateradar , ctxrobottoradar, "it.unibo.populateradar.MsgHandle_Populateradar"   ). %%store msgs 
qactor( populateradar_ctrl , ctxrobottoradar, "it.unibo.populateradar.Populateradar"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

