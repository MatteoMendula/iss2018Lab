%====================================================================================
% Context ctxRadarToSubscriber  SYSTEM-configuration: file it.unibo.ctxRadarToSubscriber.radarToSubscriber.pl 
%====================================================================================
context(ctxradartosubscriber, "localhost",  "TCP", "8085" ).  		 
context(ctxradar, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
qactor( radareventsubscriber , ctxradartosubscriber, "it.unibo.radareventsubscriber.MsgHandle_Radareventsubscriber"   ). %%store msgs 
qactor( radareventsubscriber_ctrl , ctxradartosubscriber, "it.unibo.radareventsubscriber.Radareventsubscriber"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

