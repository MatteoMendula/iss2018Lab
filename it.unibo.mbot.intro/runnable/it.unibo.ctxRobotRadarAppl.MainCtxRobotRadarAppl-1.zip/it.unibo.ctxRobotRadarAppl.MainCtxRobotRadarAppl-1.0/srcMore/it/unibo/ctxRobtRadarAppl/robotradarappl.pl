%====================================================================================
% Context ctxRobtRadarAppl  SYSTEM-configuration: file it.unibo.ctxRobtRadarAppl.robotRadarAppl.pl 
%====================================================================================
context(ctxrobtradarappl, "localhost",  "TCP", "8095" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
context(ctxradarbase, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
qactor( robotradarappl , ctxrobtradarappl, "it.unibo.robotradarappl.MsgHandle_Robotradarappl"   ). %%store msgs 
qactor( robotradarappl_ctrl , ctxrobtradarappl, "it.unibo.robotradarappl.Robotradarappl"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

