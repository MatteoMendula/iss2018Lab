%====================================================================================
% Context ctxRobotToPublisher  SYSTEM-configuration: file it.unibo.ctxRobotToPublisher.robotToPublisher.pl 
%====================================================================================
context(ctxrobottopublisher, "localhost",  "TCP", "8075" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
qactor( roboteventpublisher , ctxrobottopublisher, "it.unibo.roboteventpublisher.MsgHandle_Roboteventpublisher"   ). %%store msgs 
qactor( roboteventpublisher_ctrl , ctxrobottopublisher, "it.unibo.roboteventpublisher.Roboteventpublisher"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

