%====================================================================================
% Context ctxMbotAppl  SYSTEM-configuration: file it.unibo.ctxMbotAppl.mbotAppl.pl 
%====================================================================================
context(ctxmbotappl, "192.168.43.229",  "TCP", "8055" ).  		 
context(ctxmbotcontrol, "192.168.43.67",  "TCP", "8029" ).  		 
%%% -------------------------------------------
qactor( sonardetector , ctxmbotappl, "it.unibo.sonardetector.MsgHandle_Sonardetector"   ). %%store msgs 
qactor( sonardetector_ctrl , ctxmbotappl, "it.unibo.sonardetector.Sonardetector"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

