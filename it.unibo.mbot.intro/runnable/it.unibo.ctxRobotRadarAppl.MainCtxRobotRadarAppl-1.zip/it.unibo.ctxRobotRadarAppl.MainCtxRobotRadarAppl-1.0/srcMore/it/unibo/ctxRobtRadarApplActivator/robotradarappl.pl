%====================================================================================
% Context ctxRobtRadarApplActivator  SYSTEM-configuration: file it.unibo.ctxRobtRadarApplActivator.robotRadarAppl.pl 
%====================================================================================
context(ctxrobtradarapplactivator, "localhost",  "TCP", "8095" ).  		 
%%% -------------------------------------------
qactor( robotradarapplactivator , ctxrobtradarapplactivator, "it.unibo.robotradarapplactivator.MsgHandle_Robotradarapplactivator"   ). %%store msgs 
qactor( robotradarapplactivator_ctrl , ctxrobtradarapplactivator, "it.unibo.robotradarapplactivator.Robotradarapplactivator"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

