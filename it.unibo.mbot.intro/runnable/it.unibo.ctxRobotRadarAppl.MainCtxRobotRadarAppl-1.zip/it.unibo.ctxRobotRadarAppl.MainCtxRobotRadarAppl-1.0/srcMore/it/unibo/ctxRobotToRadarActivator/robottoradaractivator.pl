%====================================================================================
% Context ctxRobotToRadarActivator  SYSTEM-configuration: file it.unibo.ctxRobotToRadarActivator.robotToRadarActivator.pl 
%====================================================================================
context(ctxrobottoradaractivator, "localhost",  "TCP", "8055" ).  		 
%%% -------------------------------------------
qactor( componentactivator , ctxrobottoradaractivator, "it.unibo.componentactivator.MsgHandle_Componentactivator"   ). %%store msgs 
qactor( componentactivator_ctrl , ctxrobottoradaractivator, "it.unibo.componentactivator.Componentactivator"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

