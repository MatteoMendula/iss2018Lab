%====================================================================================
% Context ctxRadarUsage  SYSTEM-configuration: file it.unibo.ctxRadarUsage.radarForRobot.pl 
%====================================================================================
context(ctxradarusage, "localhost",  "TCP", "8022" ).  		 
context(ctxradarbase, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
qactor( radartest , ctxradarusage, "it.unibo.radartest.MsgHandle_Radartest"   ). %%store msgs 
qactor( radartest_ctrl , ctxradarusage, "it.unibo.radartest.Radartest"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

