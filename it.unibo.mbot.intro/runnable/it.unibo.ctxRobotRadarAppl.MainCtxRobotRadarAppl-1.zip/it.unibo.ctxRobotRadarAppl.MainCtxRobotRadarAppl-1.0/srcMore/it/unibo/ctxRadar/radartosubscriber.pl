%====================================================================================
% Context ctxRadar standalone= SYSTEM-configuration: file it.unibo.ctxRadar.radarToSubscriber.pl 
%====================================================================================
context(ctxradar, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
