%====================================================================================
% Context ctxMbotControl  SYSTEM-configuration: file it.unibo.ctxMbotControl.robotToRadar.pl 
%====================================================================================
context(ctxrobottoradaradapter, "localhost",  "TCP", "8055" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
qactor( populateradar , ctxrobottoradaradapter, "it.unibo.populateradar.MsgHandle_Populateradar"   ). %%store msgs 
qactor( populateradar_ctrl , ctxrobottoradaradapter, "it.unibo.populateradar.Populateradar"   ). %%control-driven 
qactor( componentactivator , ctxrobottoradaradapter, "it.unibo.componentactivator.MsgHandle_Componentactivator"   ). %%store msgs 
qactor( componentactivator_ctrl , ctxrobottoradaradapter, "it.unibo.componentactivator.Componentactivator"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

