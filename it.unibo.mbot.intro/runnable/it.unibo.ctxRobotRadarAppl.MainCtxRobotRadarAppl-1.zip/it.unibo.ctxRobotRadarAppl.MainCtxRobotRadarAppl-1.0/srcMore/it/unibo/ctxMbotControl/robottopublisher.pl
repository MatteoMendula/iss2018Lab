%====================================================================================
% Context ctxMbotControl standalone= SYSTEM-configuration: file it.unibo.ctxMbotControl.robotToPublisher.pl 
%====================================================================================
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
