%====================================================================================
% Context ctxMbotControl  SYSTEM-configuration: file it.unibo.ctxMbotControl.robotToRadarAdapter.pl 
%====================================================================================
context(ctxrobottoradaradapter, "localhost",  "TCP", "8055" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
qactor( populateradar , ctxrobottoradaradapter, "it.unibo.populateradar.MsgHandle_Populateradar"   ). %%store msgs 
qactor( populateradar_ctrl , ctxrobottoradaradapter, "it.unibo.populateradar.Populateradar"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

