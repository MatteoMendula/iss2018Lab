%====================================================================================
% Context ctxMbotControl standalone= SYSTEM-configuration: file it.unibo.ctxMbotControl.mbotAppl.pl 
%====================================================================================
context(ctxmbotcontrol, "192.168.43.67",  "TCP", "8029" ).  		 
%%% -------------------------------------------
