%====================================================================================
% Context ctxMbotControl  SYSTEM-configuration: file it.unibo.ctxMbotControl.robotRadarAppl.pl 
%====================================================================================
context(ctxrobotradarappl, "localhost",  "TCP", "8095" ).  		 
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
context(ctxradarbase, "localhost",  "TCP", "8033" ).  		 
%%% -------------------------------------------
qactor( robotradarappl , ctxrobotradarappl, "it.unibo.robotradarappl.MsgHandle_Robotradarappl"   ). %%store msgs 
qactor( robotradarappl_ctrl , ctxrobotradarappl, "it.unibo.robotradarappl.Robotradarappl"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

