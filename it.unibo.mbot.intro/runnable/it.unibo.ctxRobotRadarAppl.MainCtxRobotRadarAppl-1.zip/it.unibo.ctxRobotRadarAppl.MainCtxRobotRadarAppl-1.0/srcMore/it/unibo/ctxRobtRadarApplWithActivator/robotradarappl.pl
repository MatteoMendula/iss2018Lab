%====================================================================================
% Context ctxRobtRadarApplWithActivator  SYSTEM-configuration: file it.unibo.ctxRobtRadarApplWithActivator.robotRadarAppl.pl 
%====================================================================================
context(ctxrobtradarapplwithactivator, "localhost",  "TCP", "8095" ).  		 
%%% -------------------------------------------
qactor( componentactivator , ctxrobtradarapplwithactivator, "it.unibo.componentactivator.MsgHandle_Componentactivator"   ). %%store msgs 
qactor( componentactivator_ctrl , ctxrobtradarapplwithactivator, "it.unibo.componentactivator.Componentactivator"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

