%====================================================================================
% Context ctxMbotControl standalone= SYSTEM-configuration: file it.unibo.ctxMbotControl.radargui.pl 
%====================================================================================
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
