%====================================================================================
% Context ctxMbotControl standalone= SYSTEM-configuration: file it.unibo.ctxMbotControl.robotToRadar.pl 
%====================================================================================
context(ctxmbotcontrol, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
