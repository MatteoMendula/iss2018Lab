%====================================================================================
% Context ctxTestMqtt  SYSTEM-configuration: file it.unibo.ctxTestMqtt.sonarSensorEmitter.pl 
%====================================================================================
context(ctxtestmqtt, "192.168.1.19",  "TCP", "5023" ).  		 
%%% -------------------------------------------
qactor( qatestemitter , ctxtestmqtt, "it.unibo.qatestemitter.MsgHandle_Qatestemitter"   ). %%store msgs 
qactor( qatestemitter_ctrl , ctxtestmqtt, "it.unibo.qatestemitter.Qatestemitter"   ). %%control-driven 
qactor( perceiver , ctxtestmqtt, "it.unibo.perceiver.MsgHandle_Perceiver"   ). %%store msgs 
qactor( perceiver_ctrl , ctxtestmqtt, "it.unibo.perceiver.Perceiver"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

