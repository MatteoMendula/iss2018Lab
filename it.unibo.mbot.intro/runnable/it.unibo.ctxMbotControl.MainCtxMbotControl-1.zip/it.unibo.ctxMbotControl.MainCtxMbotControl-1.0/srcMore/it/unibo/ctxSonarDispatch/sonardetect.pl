%====================================================================================
% Context ctxSonarDispatch  SYSTEM-configuration: file it.unibo.ctxSonarDispatch.sonarDetect.pl 
%====================================================================================
context(ctxsonardispatch, "192.168.43.229",  "TCP", "8039" ).  		 
%%% -------------------------------------------
qactor( sonartoradar , ctxsonardispatch, "it.unibo.sonartoradar.MsgHandle_Sonartoradar"   ). %%store msgs 
qactor( sonartoradar_ctrl , ctxsonardispatch, "it.unibo.sonartoradar.Sonartoradar"   ). %%control-driven 
%%% -------------------------------------------
%%% -------------------------------------------

