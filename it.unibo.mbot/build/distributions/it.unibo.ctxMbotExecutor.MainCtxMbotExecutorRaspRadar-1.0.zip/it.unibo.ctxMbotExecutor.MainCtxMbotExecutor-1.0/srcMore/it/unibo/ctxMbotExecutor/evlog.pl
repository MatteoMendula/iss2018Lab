%====================================================================================
% Context ctxMbotExecutor standalone= SYSTEM-configuration: file it.unibo.ctxMbotExecutor.evlog.pl 
%====================================================================================
context(ctxmbotexecutor, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
