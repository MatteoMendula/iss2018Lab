%====================================================================================
% Context ctxMbotExecutor standalone= SYSTEM-configuration: file it.unibo.ctxMbotExecutor.testMbotAgent.pl 
%====================================================================================
context(ctxmbotexecutor, "localhost",  "TCP", "8029" ).  		 
%%% -------------------------------------------
